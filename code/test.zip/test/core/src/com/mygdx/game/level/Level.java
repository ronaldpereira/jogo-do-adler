/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.level;

import com.badlogic.gdx.math.Vector2;
import java.util.ArrayList;

/**
 *
 * @author Hiago
 */
public class Level 
{
    ArrayList<LevelNode> stageNodes;
    int currentNode = 0;
    protected String folder;
    
    //Construtor vazio para serialização
    private Level()
    {
        
    }

    public Level(String name, ArrayList<LevelNode> stageNodes)
    {
        this.folder = "Maps/" + name;
        this.stageNodes = stageNodes;
        for(int i = 0;i < this.stageNodes.size();i++)
        {
            this.stageNodes.get(i).setMapPath(folder);
            this.stageNodes.get(i).setMapName(Integer.toString(i));
        }
    }
    
    public LevelNode getNode(int index)
    {
        LevelNode temp = stageNodes.get(index);
        if(temp.getMap() == null)
        { 
            temp.loadMap();
        }
        return temp;
    }
     
    public LevelNode getInitialNode()
    {
        return getNode(0);
    }
    
    public String getFolder()
    {
        return folder;
    }

    public LevelNode getCurrentNode() 
    {
        return getNode(currentNode);
    }
    
    public void addNode(LevelNode node)
    {
        stageNodes.add(node);
        stageNodes.get(stageNodes.size() - 1).setMapPath(folder);
        stageNodes.get(stageNodes.size() - 1).setMapName(Integer.toString((stageNodes.size() - 1)));
    }
    
    public void nextLevel()
    {
        currentNode++;
        if(currentNode > stageNodes.size())
        {
            System.out.println("currentNode grande demais!");
        }
    }
}
