/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.tile;

import com.mygdx.game.BoundingBox;
import com.mygdx.game.CollisionInfo;
import com.mygdx.game.collidable.ICollidable;
import com.mygdx.game.TextureSheet;

/**
 *
 * @author Hiago
 */
public class Hazard extends AbstractTile
{
    BoundingBox dangerArea;
    private Hazard()
    {
        super();
    }
    public Hazard(int x,int y,TextureSheet sheet,Boolean animates)
    {
        super(x,y,sheet,animates,true);
        this.checksCollision = true;
        dangerArea = new BoundingBox(0,0,getBoundingBox().width,getBoundingBox().height);
    }
    
    @Override
    public void collide(ICollidable obj, CollisionInfo info) {
        obj.handleCollision(this,info);
    }
    public void setDangerArea(BoundingBox box)
    {
        dangerArea = new BoundingBox(box);
        dangerArea.setPositionRelative(getBoundingBox());
    }
    
    public BoundingBox getDangerArea()
    {
        return dangerArea;
    }
}
