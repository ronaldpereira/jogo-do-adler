/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.tile;

import com.mygdx.game.CollisionInfo;
import com.mygdx.game.collidable.ICollidable;
import com.mygdx.game.TextureSheet;
import com.mygdx.game.level.Level;

/**
 *
 * @author Hiago
 */
public class LevelEndingTile extends AbstractTile
{
    
    Level level;
    private LevelEndingTile()
    {
        super();
        
    }
    
    public LevelEndingTile(int x,int y,TextureSheet sheet,Boolean animates,Level level)
    {
        super(x,y,sheet,animates,true);
        this.level = level;
    }
    
    public void effect()
    {
        level.nextLevel();
    }
    @Override    
    public void collide(ICollidable obj,CollisionInfo info)
    {   
        obj.handleCollision(this,info);
    } 
    
    public Level getLevel()
    {
        return level;
    }
}
