/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.state;

import com.mygdx.game.ControllableCharacter;

/**
 *
 * @author Hiago
 */
public class PlayerJumpState extends AnimationState
{
    public PlayerJumpState(StateMachine machine,ControllableCharacter player)
    {
        super(machine,player);
        animIndex = 2;
    }
    
    public void update()
    {
        if(player.getCurrentSpeed().y == 0)
        {
            if(player.getCurrentSpeed().x != 0)
            {
                machine.setState(new PlayerMovingState(machine,player));
            }
            else if(player.isGrounded())
            {
                machine.setState(new PlayerStateIdle(machine,player));
            }
        }
    }
}
