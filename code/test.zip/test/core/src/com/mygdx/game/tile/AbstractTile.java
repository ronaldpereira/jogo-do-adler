/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.tile;

import com.mygdx.game.collidable.CollidableObject;
import com.mygdx.game.CollisionInfo;
import com.mygdx.game.collidable.ICollidable;
import com.mygdx.game.TextureSheet;

/**
 *
 * @author Adler Ito
 */
public abstract class AbstractTile extends CollidableObject //implements ItileDispatcher
{   
    public Boolean autotiles = false;
    public AbstractTile()
    {
        super(0,0,null,false);
    }
    public AbstractTile(int x,int y,TextureSheet sheet,Boolean animates,Boolean blocks)
    {
        super(x,y,sheet,animates);
        checksCollision = blocks;
        blocksMovement = blocks;
    }
    
    //Deve ser overriden em todos os filhos de AbstractTile 
//    @Override
//    public abstract AbstractTile createNew(AbstractTile tile,int x,int y);
    //Deve ser overriden em todos os filhos de CollidableObject
    @Override
    public abstract void collide(ICollidable obj,CollisionInfo info);

}
