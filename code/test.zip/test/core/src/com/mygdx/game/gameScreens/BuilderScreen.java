/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.gameScreens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.mygdx.game.BoundingBox;
import com.mygdx.game.map.CollisionMap;
import com.mygdx.game.ControllableCharacter;
import com.mygdx.game.FollowerCamera;
import com.mygdx.game.mapBuilder.MapBuilder;
import com.mygdx.game.TextureSheet;
import com.mygdx.game.level.Level;
import com.mygdx.game.level.LevelNode;
import com.mygdx.game.level.LevelSerializer;
import com.mygdx.game.mapBuilder.LevelSelector;
import java.util.ArrayList;

/**
 *
 * @author Hiago
 */
public class BuilderScreen extends ScreenAdapter
{
    //Essa classe representa a tela do construtor de mapas
    
    Stage stage;
    Skin skin = new Skin(Gdx.files.internal("uiskin.json"));
    SpriteBatch uiBatch;
    
    CollisionMap map;
    MapBuilder editor;
    
    SpriteBatch batch;
    FollowerCamera camera;
    Game game;
    
    Level level;
    ArrayList<LevelNode> nodes;
    LevelSerializer serializer;
  
    public BuilderScreen(Game game, Level level)
    {
        
       serializer = new LevelSerializer(level.getFolder());
       this.level = level;
       this.map = level.getInitialNode().getMap();
       
       this.stage = new Stage();
       this.game = game;
       this.batch = new SpriteBatch();
       this.uiBatch = new SpriteBatch();
       
       //Configura a camera:
       this.camera = new FollowerCamera(map,0,0,120,200,new BoundingBox(0,0,0,0));
       this.camera.setSpeed(0.1f);
       this.camera.setToOrtho(false,640,360);
       
       this.editor = new MapBuilder(this.level,batch,camera,stage);
        
    }
    
    @Override
    public void resize(int width, int height)
    {
        
        stage.getViewport().update(width, height, true);
    }
    
    @Override
    public void render(float delta)
    {
        Gdx.gl.glClearColor(0.2f, 0.2f, 0.5f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        
        if(Gdx.input.isKeyPressed(Input.Keys.F11))
        {
            serializer.storeStage(level);
            ControllableCharacter player = new ControllableCharacter(new TextureSheet(new Texture("Adler.png"),23,38),true,level);
            map.addPlayer(player);
            player.setLevelNode(level.getInitialNode());
            player.getBoundingBox().setWidth(23);
            player.getBoundingBox().setHeight(31);
            this.dispose();
            game.setScreen(new StageScreen(player,level,game));

            return;
        }
        
        //Atualiza o boudingBox que a camera está seguindo dependendo da posição do mouse:
        camera.setBounds(editor.getMouseBox());
        camera.update();
        
        editor.update();

        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        editor.renderBuilder(batch);
        batch.end();
        
        uiBatch.begin();
        editor.renderBuilderUI();
        uiBatch.end();
    }
    
    @Override
    public void dispose()
    {
        batch.dispose();
        editor.dispose();
    }
}
