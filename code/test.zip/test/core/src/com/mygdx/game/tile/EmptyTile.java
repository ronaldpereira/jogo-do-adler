/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.tile;

import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.Json.Serializable;
import com.badlogic.gdx.utils.JsonValue;
import com.mygdx.game.BoundingBox;
import com.mygdx.game.CollisionInfo;
import com.mygdx.game.map.CollisionMap;
import com.mygdx.game.collidable.ICollidable;

/**
 *
 * @author Hiago
 */
public class EmptyTile extends AbstractTile implements Serializable
{
    //string name;
    public EmptyTile()
    {
        super(0,0,null,false,false);
    }
    public EmptyTile(int x,int y)
    {
        super(x,y,null,false,false);
    }
    
//    @Override
//    public EmptyTile createNew(AbstractTile tile,int x,int y)
//    {
//        return TileFactory.createEmpty(x,y);
//    }
    
    @Override    
    public void collide(ICollidable obj,CollisionInfo info)
    {   
        obj.handleCollision(this,info);
    }   

    @Override
    public void write(Json json) 
    {
        json.writeValue("x",this.getBoundingBox().getX());
        json.writeValue("y",this.getBoundingBox().getY());
    }

    @Override
    public void read(Json json, JsonValue jsonData) 
    {
        this.setBoundingBox(new BoundingBox(jsonData.getInt("x"),
            jsonData.getInt("y"),CollisionMap.tileSize,CollisionMap.tileSize));
    }
}
