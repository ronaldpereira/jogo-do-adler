/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.map;

import com.mygdx.game.collidable.CollidableObject;
import com.mygdx.game.enemy.AbstractEnemy;
import com.mygdx.game.enemy.EnemyFactory;
import com.mygdx.game.enemy.WalkerEnemy;
import com.mygdx.game.tile.AbstractTile;
import com.mygdx.game.tile.Coin;
import com.mygdx.game.tile.EmptyTile;
import com.mygdx.game.tile.Hazard;
import com.mygdx.game.tile.LevelEndingTile;
import com.mygdx.game.tile.Repulsor;
import com.mygdx.game.tile.Tile;
import com.mygdx.game.tile.TileFactory;

/**
 *
 * @author Hiago
 */
public class CollidableObjectFactory 
{
    public static AbstractEnemy createNewEnemy(int x,int y,CollidableObject generator)
    {
        if(generator instanceof WalkerEnemy)
        {
            return EnemyFactory.createEnemy((WalkerEnemy)generator, x, y);
        }
        return null;
    }
    
    public static AbstractTile createNewTile(int x,int y,CollidableObject generator)
    {
        if(generator instanceof Tile)
        {
            return TileFactory.createTile((Tile)generator,x,y);
        }
        else if(generator instanceof EmptyTile)
        {
            return TileFactory.createEmpty(x,y);
        }
        else if(generator instanceof Repulsor)
        {
            return TileFactory.createRepulsor((Repulsor)generator,x,y);
        }
        else if(generator instanceof Coin)
        {
            return TileFactory.createCoin((Coin)generator,x,y);
        }
        else if(generator instanceof Hazard)
        {
            return TileFactory.createHazard((Hazard)generator,x,y);
        }
        else if(generator instanceof LevelEndingTile)
        {
            return TileFactory.createEnding((LevelEndingTile)generator, x, y);
        }
        return null;
    }
    
   
}
