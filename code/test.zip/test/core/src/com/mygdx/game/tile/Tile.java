/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.tile;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.graphics.Texture; 
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.mygdx.game.CollisionInfo;
import com.mygdx.game.collidable.ICollidable;
import com.mygdx.game.TextureSheet;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
/**
 *
 * @author Hiago
 */
public class Tile extends AbstractTile 
{
    //Valores default:
    private float attrition = 0.075f;
    private float maxSpeed = 8f;  
    
    public Tile()
    {
        super();
        autotiles = true;
    }
    
    public Tile(int x,int y,TextureSheet sheet,Boolean animates,Boolean blocks,Boolean autotiles)
    {
        super(x,y,sheet,animates,blocks);
        checksCollision = blocks;
        blocksMovement = blocks;
        this.autotiles = autotiles;      
    }
    
    public Tile(int x,int y,TextureSheet sheet,Boolean animates,Boolean blocks,float attrition,float maxSpeed,Boolean autotiles)
    {
        super(x,y,sheet,animates,blocks);
        
        checksCollision = blocks;
        blocksMovement = blocks;
        this.attrition = attrition;
        this.maxSpeed = maxSpeed;
        this.autotiles = autotiles;
    }
    
    public void setAutoTiles(Boolean value)
    {
        autotiles = value;
    }
    
    public void setAttrition(float value)
    {
        attrition = value;
    }
  
    public float getAttrition()
    {
        return attrition;
    }
    
    public void setMaxSpeed(float value)
    {
        maxSpeed = value;
    }
    
    public float getMaxSpeed()
    {
        return maxSpeed;
    }
    
    @Override    
    public void collide(ICollidable obj,CollisionInfo info)
    {   
        obj.handleCollision(this,info);
    } 
}
