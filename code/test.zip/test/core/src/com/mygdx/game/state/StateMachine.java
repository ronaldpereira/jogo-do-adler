/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.state;

import com.mygdx.game.ControllableCharacter;
import java.util.Dictionary;

/**
 *
 * @author Hiago
 */
public class StateMachine 
{
    IState current;
    ControllableCharacter player;
    private StateMachine()
    {
        
    }
    public StateMachine(ControllableCharacter player)
    {
        this.player = player;
        current = new PlayerStateIdle(this,player);
    }
    
    public void update()
    {
        current.update();
    }
    
    public void setState(IState state)
    {
        current.onExit();
        current = state;
        current.onEnter();
    }
}
