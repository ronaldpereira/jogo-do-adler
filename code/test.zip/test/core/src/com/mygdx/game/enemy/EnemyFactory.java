/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.enemy;

import com.badlogic.gdx.math.Vector2;
import com.mygdx.game.BoundingBox;
import com.mygdx.game.TextureSheet;

/**
 *
 * @author Hiago
 */
public class EnemyFactory 
{
    public static WalkerEnemy createEnemy(WalkerEnemy enemy,int x,int y)
    {
        WalkerEnemy clone =  new WalkerEnemy(new Vector2(x,y), enemy.getSheet(), enemy.getAnimated());
        clone.setBoundingBox(new BoundingBox(x,y,enemy.getBoundingBox().width,enemy.getBoundingBox().height));
        return clone;
    }
}
