/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.state;

import com.mygdx.game.ControllableCharacter;
import static java.lang.Math.signum;

/**
 *
 * @author Hiago
 */
public class PlayerDirChangeState extends AnimationState
{
  private PlayerDirChangeState()
    {
        super(null,null);  
        animIndex = 3;   
    }
    public PlayerDirChangeState(StateMachine machine,ControllableCharacter player)
    {
        super(machine,player);
        animIndex = 3;
        
    }
    
    @Override
    public void update()
    {
        if(player.getCurrentSpeed().y != 0)
        {
            machine.setState(new PlayerJumpState(machine,player));
        }
        else if(signum(player.getCurrentSpeed().x) == signum(player.getAccel().x))
        {
            machine.setState(new PlayerMovingState(machine,player));
        }
    }  
}
