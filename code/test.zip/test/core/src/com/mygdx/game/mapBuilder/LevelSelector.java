/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.mapBuilder;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.HorizontalGroup;
import com.badlogic.gdx.scenes.scene2d.ui.ScrollPane;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.SplitPane;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.mygdx.game.gameScreens.BuilderScreen;
import com.mygdx.game.level.LevelSerializer;

/**
 *
 * @author Hiago
 */
public class LevelSelector extends Window
{
    ScrollPane levelPane;
    ConfirmableTextField field;
    FolderSelector levels;
    TextButton newButton;
    TextButton cancelButton;
    TextButton okButton;
    String selectedLevel;
    
    public LevelSelector(Skin uiSkin,final Game game)
    {
        super("Level Selector",uiSkin);
        this.center();
        levels = new FolderSelector("Maps/",uiSkin);
        newButton = new TextButton("New",uiSkin);
        okButton = new TextButton("Ok",uiSkin);
        cancelButton = new TextButton("Cancel",uiSkin);
        field = new NewLevelField(uiSkin);
        field.addListener(new ChangeListener() 
        {
            @Override
            public void changed(ChangeListener.ChangeEvent event, Actor actor) 
            {
                levels.updateList();
            }
        }); 
        field.setVisible(false);
        newButton.addListener(new ClickListener()
            {
                @Override
                public void clicked(InputEvent event,float x,float y)
                {
                    field.setVisible(true);
                }
            }
        );
        
        cancelButton.addListener(new ClickListener()
            {
                @Override
                public void clicked(InputEvent event,float x,float y)
                {
                    setVisible(false);
                }
            }
        );
        
        okButton.addListener(new ClickListener()
            {
                @Override
                public void clicked(InputEvent event,float x,float y)
                {
                    selectedLevel = levels.currentMap;
                    if(selectedLevel != null)
                    {
                        LevelSerializer sel = new LevelSerializer(selectedLevel);
                        game.getScreen().dispose();
                        game.setScreen(new BuilderScreen(game, sel.loadStage()));
                    }
                }
            }
        );

       

        levelPane = new ScrollPane(levels);
        this.add(levelPane).pad(30);
        this.row();
        this.add(okButton);
        this.add(newButton);
        this.add(cancelButton);
       // this.add(cancelButton);
        this.addActor(field);
        //this.setDebug(true);
        
        
    }
}
