/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.mapBuilder;

import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.ui.Window;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener.ChangeEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

/**
 *
 * @author Hiago
 */
public abstract class ConfirmableTextField extends Window 
{
    private Label fieldLabel;
    private TextButton confirmButton;
    private TextButton cancelButton;
    private TextField field;
    protected String fieldText;
    
    public ConfirmableTextField(String name, String label,Skin uiSkin)
    {
        super(name,uiSkin);
        fieldLabel = new Label(label,uiSkin);
        field = new TextField("",uiSkin);
        confirmButton = new TextButton("Ok",uiSkin);
        confirmButton.addListener(new ClickListener()
        {
                @Override
                public void clicked(InputEvent event,float x,float y)
                {
                    fieldText = field.getText();
                    if(!fieldText.equals(""))
                    {
                        onConfirm();
                        setVisible(false);
                        field.setText("");
                        fire(new ChangeEvent());
                    }
                }
            }
        );
        cancelButton = new TextButton("Cancel",uiSkin);
        cancelButton.addListener(new ClickListener()
        {
                @Override
                public void clicked(InputEvent event,float x,float y)
                {
                    setVisible(false);
                }
            }
        );
        
        this.add(fieldLabel);
        this.add(field).expand();
        this.row();
        this.add(confirmButton);
        this.add(cancelButton);
       
    }
    
    protected abstract void onConfirm();
}
