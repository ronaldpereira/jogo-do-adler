/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.tile;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Animation.PlayMode;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.mygdx.game.CollisionInfo;
import com.mygdx.game.ControllableCharacter;
import com.mygdx.game.collidable.DynamicCollider;
import com.mygdx.game.collidable.ICollidable;
import com.mygdx.game.TextureSheet;

/**
 *
 * @author Hiago
 */
public class Coin extends Pickup
{
    //
    //Texture coinSheet;
    
   
    public Coin()
    {
        super(0,0,null,false);
    }
    private int value = 5;
    public Coin(int x,int y,TextureSheet sheet,Boolean animates)
    {
        
        //atlas = new TextureAtlas(Gdx.files.internal("CoinAnim"))
        super(x,y,sheet,animates);
        //coinSpr = new Animation<TextureRegion>(0.033f,atlas.findRegion("Coin"),PlayMode.LOOP);
    }
    
    @Override
    public void effect(ControllableCharacter player)
    {
        player.coins += value;
    }

    @Override    
    public void collide(ICollidable obj,CollisionInfo info)
    {   
        obj.handleCollision(this,info);
    } 
}
