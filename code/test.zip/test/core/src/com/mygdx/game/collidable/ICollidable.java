/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.collidable;

import com.mygdx.game.CollisionInfo;
import com.mygdx.game.ControllableCharacter;
import com.mygdx.game.enemy.AbstractEnemy;
import com.mygdx.game.enemy.WalkerEnemy;
import com.mygdx.game.tile.*;


/**
 *
 * @author Hiago
 */
public interface ICollidable
{
    public void handleCollision(ICollidable obj,CollisionInfo info);
    public void handleCollision(AbstractTile tile,CollisionInfo info);
    public void handleCollision(Tile tile,CollisionInfo info);
    public void handleCollision(DynamicCollider character,CollisionInfo info);
    public void handleCollision(ControllableCharacter player,CollisionInfo info);
    public void handleCollision(AbstractEnemy enemy,CollisionInfo info);
    public void handleCollision(Repulsor repulsor,CollisionInfo info);
    public void handleCollision(WalkerEnemy enemy, CollisionInfo info);
    public void handleCollision(Hazard hazard, CollisionInfo info);
    public void handleCollision(LevelEndingTile end, CollisionInfo info);
    public void collide(ICollidable obj,CollisionInfo info);
}
