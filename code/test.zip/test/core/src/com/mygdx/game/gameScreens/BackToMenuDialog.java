/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.gameScreens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;

/**
 *
 * @author Hiago
 */
public class BackToMenuDialog extends Dialog 
{
    TextButton confirmButton;
    TextButton cancelButton;
    Game game;
            
    public BackToMenuDialog(Skin skin,Game game) {
        super("Exit", skin);
        this.game = game;
        confirmButton = new TextButton("Ok",skin);
        cancelButton = new TextButton("Cancel",skin);
        
        this.text("Return to main menu?");
        this.button(confirmButton,1L);
        this.button(cancelButton,2L);
    }
    
    @Override
    protected void result(Object object)
    {
        if(object.equals(1L))
        {
            game.getScreen().dispose();
            game.setScreen(new InitialScreen(game));
        }
        else
        {
            this.setVisible(false);
        }
    }
    
}
