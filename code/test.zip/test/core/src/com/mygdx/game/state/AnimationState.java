/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.state;

import com.mygdx.game.ControllableCharacter;

/**
 *
 * @author Hiago
 */
public class AnimationState extends EmptyPlayerState
{
    int animIndex = 0;
    public AnimationState(StateMachine machine,ControllableCharacter player)
    {
        super(machine,player);
    }
    
    @Override
    public void onEnter()
    {
        player.setCurrentAnimation(animIndex);
    }
}
