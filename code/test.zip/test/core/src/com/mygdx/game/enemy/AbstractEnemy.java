/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.enemy;

import com.mygdx.game.tile.Tile;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;
import com.mygdx.game.CollisionInfo;
import com.mygdx.game.collidable.DynamicCollider;
import com.mygdx.game.collidable.ICollidable;
import static com.mygdx.game.Axis.HORIZONTAL_AXIS;
import static com.mygdx.game.Axis.VERTICAL_AXIS;
import com.mygdx.game.TextureSheet;
import com.mygdx.game.tile.AbstractTile;
import static java.lang.Math.abs;
import static java.lang.Math.min;
import static java.lang.Math.signum;
import com.mygdx.game.IDamageable;

/**
 *
 * @author Hiago
 */
public abstract class AbstractEnemy extends DynamicCollider implements IDamageable{
    ////TODO:MUDAR ALGUMAS COISAS
    //CHANGE:
    float xOrigin;
    int direction = 1;
    int life = 5;
    
    public void setOrigin()
    {
        if(direction < 0)
        {
            //REMOVER ISSO E TROCAR POR SKIN
            xOrigin = getBoundingBox().getRight() - 1;
        }
        else
        {
            xOrigin = getBoundingBox().getLeft() + 1;
        }
    }
    public AbstractEnemy(Vector2 initialPos, TextureSheet sheet, Boolean animates) {
        super(initialPos, sheet,animates);
        attrition = 0;
    }
    
    @Override
    public void collide(ICollidable obj,CollisionInfo info)
    {
        obj.handleCollision(this,info);
    }
    
    ////TODO:COLOCAR ISSO NO WALKER?
    @Override
    public void handleCollision(AbstractTile tile,CollisionInfo info)
    {
        
        if(info.getAxis() == HORIZONTAL_AXIS)
        {
            if(tile.getBlocks())
            {
                int distance = (int)getBoundingBox().getHorizontalDistance(tile.getBoundingBox());
                currentSpeed.x = min(distance,abs(currentSpeed.x)) * signum(currentSpeed.x);
                
                //System.out.println("Enemy Speed: "+ currentSpeed.x + "TilePosition:" + tile.getBoundingBox().getX() +"," + tile.getBoundingBox().getY());
            }
        }
        else 
        {
            if(tile.getBlocks())
            {
                int yDirection = (int)signum(currentSpeed.y);
                int distance = (int)getBoundingBox().getVerticalDistance(tile.getBoundingBox());
                currentSpeed.y = min(distance,abs(currentSpeed.y)) * yDirection;
              //  System.out.println(currentSpeed.y);
               // System.out.println(distance);

                if(yDirection <= 0 && abs((int)distance) == 0)
                {
                    grounded = true;
                }
            } 
        }
    }
    
    @Override
    public void takeDamage(int damage)
    {
        this.life -= damage;
        if(life <= 0)
        {
            die();
        }
    }
    
    @Override
    public void die()
    {
        setActive(false);
        map.removeMovingObject(this);
    }
    
}