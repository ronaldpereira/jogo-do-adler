/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.level;

import com.badlogic.gdx.math.Vector2;
import com.mygdx.game.ControllableCharacter;
import com.mygdx.game.map.CollisionMap;
import com.mygdx.game.map.MapSerializer;

/**
 *
 * @author Hiago
 */
public class LevelNode 
{
    private static final int RIGHT = 0;
    private static final int LEFT = 1;
    private static final int UP = 2;
    private static final int DOWN = 3;
    
    transient CollisionMap nodeMap;
    String mapPath;
    String name;
    Vector2 initialPosition;
    transient MapSerializer loadsave;
    
    
    //Construtor vazio para serialização
    private LevelNode()
    {
        nodeMap = null;
    }
    
    public LevelNode(CollisionMap map)
    {
        this.nodeMap = map;
        initialPosition = new Vector2(1,2);
        startLoadSave();
    }
    
    public void setMapPath(String path)
    {
        this.mapPath = path;
        loadsave.setFiles(name,mapPath);
    }
    
    public void setMapName(String name)
    {
        this.name = name;
        loadsave.setFiles(this.name,mapPath);
    }
    public void saveMap()
    {
        loadsave.storeMap(nodeMap);
    }
    
    public void loadMap()
    {
        nodeMap = new CollisionMap(0,0);
        loadsave.loadMap(nodeMap);
    }
    
    public void startLoadSave()
    {
        loadsave = new MapSerializer(name,mapPath);
    }
    
    public CollisionMap getMap()
    {
        if(nodeMap == null)
        {
            loadMap();
        }
        
        return nodeMap;
    }
    
    public Vector2 getInitialPos()
    {
        return initialPosition;
    }
    
    public void reloadObjects()
    {
        loadsave.reloadDynamic(nodeMap);
    }
}
