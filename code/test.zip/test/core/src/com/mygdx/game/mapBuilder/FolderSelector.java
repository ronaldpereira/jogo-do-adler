/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.mapBuilder;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.List;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import java.io.File;
import java.util.ArrayList;

/**
 *
 * @author Hiago
 */
public class FolderSelector extends Table 
{   
    //Essa clase representa a UI do seletor de mapas no editor de niveis;
  
    String currentMap;      
    String stageName;
    FileHandle[] maps;
    FileHandle file;
    List foundMaps;
    int selectedStage = 0;
    
    public FolderSelector(String directory, Skin uiSkin)
    {
       
        this.stageName = directory;
        file = Gdx.files.local(stageName);
        maps = file.list();
        
        //Cada diretorio representa um mapa diferente e tem um botão designado a ele
        Label tmpLabel;
        foundMaps = new List(uiSkin);
        ArrayList<FileHandle> folders = new ArrayList<FileHandle>();
        for(FileHandle map : maps)
        {
            if(map.isDirectory())
            {
                folders.add(map);
                //tmpList.setItems(map);
                /*
                final int index = i;
                tmpLabel = new Label(map.name(),uiSkin);
                tmpButton = new Button(tmpLabel,uiSkin);
                tmpButton.addListener(new ClickListener()
                {
                    @Override
                    public void clicked(InputEvent event,float x,float y)
                    {
                        selectedStage = index;
                        System.out.println(index);
                    }
                }
                );
                this.add(tmpButton).width(100).pad(10);
                this.row();
                i++;
                */
            }
        }
        foundMaps.setItems(folders.toArray(new FileHandle[0]));
        this.add(foundMaps);
        this.addListener(new ChangeListener() 
        {
            @Override
                 public void changed(ChangeListener.ChangeEvent event, Actor actor) 
                 {
                     System.out.println("a");
                     currentMap = foundMaps.getSelected().toString();
                     System.out.println(currentMap);
                 }
        }
        );
    }

    public void updateList() 
    {
        file = Gdx.files.local(stageName);
        maps = file.list();
        ArrayList<FileHandle> folders = new ArrayList<FileHandle>();
        for(FileHandle map : maps)
        {
            if(map.isDirectory())
            {
                folders.add(map);
                //tmpList.setItems(map);
                /*
                final int index = i;
                tmpLabel = new Label(map.name(),uiSkin);
                tmpButton = new Button(tmpLabel,uiSkin);
                tmpButton.addListener(new ClickListener()
                {
                    @Override
                    public void clicked(InputEvent event,float x,float y)
                    {
                        selectedStage = index;
                        System.out.println(index);
                    }
                }
                );
                this.add(tmpButton).width(100).pad(10);
                this.row();
                i++;
                */
            }
        }
        foundMaps.setItems(folders.toArray((FileHandle[]) new FileHandle[0]));
    }
}
