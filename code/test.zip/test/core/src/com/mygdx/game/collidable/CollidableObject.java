/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.collidable;

import com.mygdx.game.map.CollisionMap;
import com.badlogic.gdx.Gdx;
import com.mygdx.game.enemy.AbstractEnemy;
import com.mygdx.game.tile.Tile;
import com.mygdx.game.tile.Repulsor;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.mygdx.game.BoundingBox;
import com.mygdx.game.CollisionInfo;
import com.mygdx.game.ControllableCharacter;
import com.mygdx.game.TextureSheet;
import com.mygdx.game.enemy.WalkerEnemy;
import com.mygdx.game.tile.AbstractTile;
import com.mygdx.game.tile.Hazard;
import com.mygdx.game.tile.LevelEndingTile;
/**
 *
 * @author Hiago
 */
public abstract class CollidableObject implements ICollidable//,Serializable
{
    //Essa classe define todos os metodos de colisão possiveis no sistema.
    //Por default, um metodo de colisão nessa classe deve chamar o método de colisão 
    //para o mesmo objeto com typeCast para o pai. Isso é feito para manter o principio
    //de substituição de liskov.
    protected Boolean checksCollision = true;
    protected Boolean blocksMovement = false;
    protected int defaultFrame = 0;
    
    private Boolean active;
    private Boolean animated;
    protected TextureSheet sheet;
    
    transient private Animation<TextureRegion>[] possibleAnimations;
    transient private Animation<TextureRegion> currentAnimation;
    
    private BoundingBox boundingBox;
    float stateTime;
    
    public CollidableObject()
    {
    }
    
    public CollidableObject(int x,int y,TextureSheet sheet,boolean animated)
    {
        setBoundingBox(new BoundingBox(x,y,CollisionMap.tileSize,CollisionMap.tileSize));
        this.active = true;
        this.sheet = sheet;
        this.animated = animated;
        this.stateTime = 0f;
        
        if(this.animated)
        {
            //Pega todas as animações na textureSheet
            this.possibleAnimations = sheet.toAnimation();
            //Usa a primeira como default.
            //*Isso pode ser mudado depois com a mudança de estado do objeto.
            this.currentAnimation = possibleAnimations[0];
        }
    }
    
    public Boolean getActive()
    {
        return this.active;
    }
    
    public void setActive(Boolean act)
    {
        this.active = act;
        if(!this.active)
        {
            this.checksCollision = false;
            this.blocksMovement = false;
        }
    }
    
    public void setDefaultFrame(int index)
    {
        this.defaultFrame = index;
    }
    
    public TextureSheet getSheet()
    {
        return this.sheet;
    }
    
    public Boolean getAnimated()
    {
        return this.animated;
    }
    
    public Boolean getCollides()
    {
        return this.checksCollision;
    }
    
    public void setCollides(Boolean checks)
    {
        this.checksCollision = checks;
    }
 
    public Boolean getBlocks()
    {
        return this.blocksMovement;
    }
    
    public void setBlocks(Boolean blocks)
    {
        if(blocks == true)
        {
            this.checksCollision = true;
        }
        this.blocksMovement = blocks;
    }
    public Animation<TextureRegion> getCurrentAnimation()
    {
        if(currentAnimation == null)
        {
            this.possibleAnimations = sheet.toAnimation();
            //Usa a primeira como default.
            //*Isso pode ser mudado depois com a mudança de estado do objeto.
            this.currentAnimation = possibleAnimations[0];
        }
        return currentAnimation;
    }
    public void drawSelf(SpriteBatch batch)
    {
        if(active && sheet != null)
        {
            if(animated)
            {
                stateTime += Gdx.graphics.getDeltaTime();
                batch.draw(getCurrentAnimation().getKeyFrame(stateTime,true),boundingBox.getX(),boundingBox.getY());
            }
            else
            {
                batch.draw(sheet.getFrame(defaultFrame),boundingBox.getX(),boundingBox.getY());
            }
        }
    }
    
    @Override
    public void handleCollision(ICollidable obj,CollisionInfo info){}
    
    @Override
    public void handleCollision(AbstractTile tile,CollisionInfo info)
    {
        handleCollision((CollidableObject) tile,info);
    } 
    
    @Override
    public void handleCollision(Tile tile,CollisionInfo info)
    {
        handleCollision((AbstractTile) tile,info);
    }      
    
    @Override
    public void handleCollision(DynamicCollider character,CollisionInfo info)
    {
        handleCollision((CollidableObject) character,info);
    }
    
    @Override
    public void handleCollision(ControllableCharacter player,CollisionInfo info)
    {
        handleCollision((DynamicCollider)player,info);
    }
    @Override
    public void handleCollision(Repulsor repulsor,CollisionInfo info)
    {
        handleCollision((AbstractTile)repulsor,info);
    }
    @Override
    public void handleCollision(AbstractEnemy enemy, CollisionInfo info)
    {
        handleCollision((DynamicCollider)enemy,info);
    }
    
    @Override
    public void handleCollision(WalkerEnemy enemy, CollisionInfo info)
    {
        handleCollision((AbstractEnemy)enemy,info);
    }
    
    @Override
    public void handleCollision(Hazard hazard, CollisionInfo info)
    {
        handleCollision((AbstractTile)hazard,info);
    }
    
    @Override
    public void handleCollision(LevelEndingTile end, CollisionInfo info)
    {
        handleCollision((AbstractTile)end,info);
    }
    
    
    @Override    
    public abstract void collide(ICollidable obj,CollisionInfo info);

    public BoundingBox getBoundingBox() {
        return boundingBox;
    }

    public void setBoundingBox(BoundingBox boundingBox) {
        this.boundingBox = boundingBox;
    }
    
    public void setCurrentAnimation(int index)
    {
        if(index < possibleAnimations.length)
        {
            currentAnimation = possibleAnimations[index];
        }
    }
}
