/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.gameScreens;

import com.badlogic.gdx.Audio;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.mygdx.game.ControllableCharacter;
import com.mygdx.game.TextureSheet;
import com.mygdx.game.level.Level;
import com.mygdx.game.level.LevelNode;
import com.mygdx.game.level.LevelSerializer;
import com.mygdx.game.map.CollisionMap;
import com.mygdx.game.mapBuilder.LevelSelector;
import java.util.ArrayList;

/**
 *
 * @author Hiago
 */
public class InitialScreen extends ScreenAdapter
{        
    public static final String mainMapName = "Maps/testlevel";
    public static Sound coinSound = Gdx.audio.newSound(Gdx.files.internal("coin.ogg"));
    public static Sound hitSound = Gdx.audio.newSound(Gdx.files.internal("Damage.ogg"));
    public static Sound jumpSound = Gdx.audio.newSound(Gdx.files.internal("Jump.ogg")); 
    public static Sound repSound = Gdx.audio.newSound(Gdx.files.internal("rep.ogg"));
    public static Music levelMusic = Gdx.audio.newMusic(Gdx.files.internal("ad3.ogg"));
    ImageButton newGame;
    ImageButton mapBuilder;
    ImageButton exit;
    Table initialScreenTable;
    Stage initialStage;
    Skin skin;
    OrthographicCamera camera;
    
    public InitialScreen(final Game game)
    {
        camera = new OrthographicCamera();
        this.camera.setToOrtho(false,640,360);
        
        skin = new Skin(Gdx.files.internal("uiskin.json"));
        final Screen thisScreen = this;
        
        /*
        ArrayList<LevelNode> temp = new ArrayList<LevelNode>();
        temp.add(new LevelNode(new CollisionMap(100,100)));
        temp.add(new LevelNode(new CollisionMap(100,100)));
        temp.add(new LevelNode(new CollisionMap(100,100)));
        firstLevel = new Level("testLevel",temp);
        LevelSerializer sel = new LevelSerializer(firstLevel.getFolder());
        sel.storeStage(firstLevel);
        */
        
        newGame = new ImageButton(new TextureRegionDrawable(new TextureRegion(new Texture("NewGameButtonUp.png"))),new TextureRegionDrawable(new TextureRegion(new Texture("NewGameDown.png"))));
        newGame.addListener(new ClickListener()
            {
                @Override
                public void clicked(InputEvent event,float x,float y)
                {
                    Level firstLevel = new LevelSerializer(mainMapName).loadStage();
                    thisScreen.dispose();
                    ControllableCharacter player = new ControllableCharacter(new TextureSheet(new Texture("Adler.png"),23,38),true,firstLevel);
                    player.getBoundingBox().width = 23;
                    player.getBoundingBox().height = 31;
                    game.setScreen(new StageScreen(player,firstLevel,game));
                }
            }
        );
        
        
       mapBuilder = new ImageButton(new TextureRegionDrawable(new TextureRegion(new Texture("MpBuilderUp.png"))),new TextureRegionDrawable(new TextureRegion(new Texture("MpBuilderDown.png"))));
       final LevelSelector lv = new LevelSelector(skin,game);
       lv.addListener(new ChangeListener() 
       {
       @Override
            public void changed(ChangeListener.ChangeEvent event, Actor actor) 
            {
              System.out.println("click");
            }
       });
       lv.setFillParent(true);
       lv.setVisible(false);

       
       mapBuilder.addListener(new ClickListener()
            {
          
            
                @Override
                public void clicked(InputEvent event,float x,float y)
                {
                    lv.setVisible(true);
                    //thisScreen.dispose();
                    //game.setScreen(new BuilderScreen(game,firstLevel));
                }
            }
        );
        
        exit = new ImageButton(new TextureRegionDrawable(new TextureRegion(new Texture("ExitUp.png"))),new TextureRegionDrawable(new TextureRegion(new Texture("QuitDown.png"))));
        exit.addListener(new ClickListener()
            {
                @Override
                public void clicked(InputEvent event,float x,float y)
                {
                    thisScreen.dispose();
                    game.dispose();
                    Gdx.app.exit();
                }
            }
        );
        
        initialStage = new Stage();
        initialScreenTable = new Table();
        initialScreenTable.setPosition(initialStage.getViewport().getScreenWidth()/2, initialStage.getViewport().getScreenHeight()/2);
        initialScreenTable.add(newGame).padBottom(20);
        initialScreenTable.row();
        initialScreenTable.add(mapBuilder).padBottom(20);
        initialScreenTable.row();
        initialScreenTable.add(exit).padBottom(20);
        initialScreenTable.row();
 
        initialStage.addActor(initialScreenTable);
        initialStage.addActor(lv);
        Gdx.input.setInputProcessor(initialStage);
        //initialStage.getViewport().setCamera(camera);
    }
    
    @Override
    public void render(float delta)
    {
        Gdx.gl.glClearColor(0.4f, 0.1f, 0.1f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        camera.update();
        initialStage.act();
        initialStage.draw();
    }
    
    @Override
    public void dispose()
    {
        initialStage.dispose();
        Gdx.input.setInputProcessor(null);
    }
    
    @Override
    public void resize(int width, int height)
    {
        System.out.println(initialStage.getViewport().getScreenWidth() + " " + initialStage.getViewport().getScreenHeight());
        initialStage.getViewport().update(width, height, true);
    }
}
