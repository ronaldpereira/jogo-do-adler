/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.tile;

import com.mygdx.game.BoundingBox;

/**
 *
 * @author Hiago
 */
public class TileFactory 
{
     public static EmptyTile createEmpty(int x,int y)
    {
        return new EmptyTile(x,y);
    }
    
    public static Tile createTile(Tile tile, int x,int y)
    {   
        System.out.println(tile.getClass());
        Tile clone = new Tile(x,y,tile.getSheet(),tile.getAnimated(),tile.getBlocks(),
                                tile.getAttrition(),tile.getMaxSpeed(),tile.autotiles);
        clone.autotiles = tile.autotiles;
        
        return clone;
    }
    
    public static Coin createCoin(Coin coin, int x,int y)
    {
        Coin clone = new Coin(x,y,coin.getSheet(),coin.getAnimated());
        return clone;
    }
    
    public static Repulsor createRepulsor(Repulsor repulsor, int x,int y)
    {
        Repulsor clone = new Repulsor(x,y,repulsor.getSheet(),repulsor.getAnimated(),repulsor.getAxis(),
                repulsor.getDirection(),repulsor.getRepulsionSpeed());
        return clone;
    }
    
    public static Hazard createHazard(Hazard hazard, int x,int y)
    {
        System.out.println(x + " " + y + " ");
        Hazard clone = new Hazard(x,y,hazard.getSheet(),hazard.getAnimated());
        clone.setDangerArea(hazard.getDangerArea());
        return clone;
    }
    
     public static LevelEndingTile createEnding(LevelEndingTile end, int x,int y)
    {
        System.out.println(x + " " + y + " ");
        LevelEndingTile clone = new LevelEndingTile(x,y,end.getSheet(),end.getAnimated(),end.getLevel());
        return clone;
    }
}
