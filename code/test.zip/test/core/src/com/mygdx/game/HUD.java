/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.StretchViewport;

/**
 *
 * @author Hiago
 */
public class HUD extends Stage
{
    Texture lifeTexture = new Texture("heart.png");
    Texture emptyLife = new Texture("emptyHeart.png");
    
    TextureRegionDrawable lifeDrawable;
    TextureRegionDrawable emptyDrawable;
    Image[] lifeImages;
    Label scoreLabel;
    
    private ControllableCharacter player;
    private int life;
    private int score;
    private Vector2 lifePosition = new Vector2(80, 400);
    private Vector2 scorePosition;
    private int lifeSpacing = 5;
    
    
    public HUD(ControllableCharacter player,Skin uiSkin)
    {
        super();
        this.setViewport(new StretchViewport(800,480));
        //this.setPosition(300, 100);
        this.player = player;
        lifeDrawable = new TextureRegionDrawable(new TextureRegion(lifeTexture));
        emptyDrawable = new TextureRegionDrawable(new TextureRegion(emptyLife));
        lifeImages = new Image[player.getLife()];
        System.out.println(lifeImages.length);
        
        for(int i = 0; i < lifeImages.length; i++)
        {
            System.out.println("??????");
            lifeImages[i] = new Image(lifeDrawable);
            lifeImages[i].setScale(2f,2f);
            
            lifeImages[i].setPosition(lifePosition.x + (lifeSpacing *i) + (lifeImages[i].getWidth() * lifeImages[i].getScaleX() * i) ,lifePosition.y);
            this.addActor(lifeImages[i]);
            //lifeImages[i].layout();
        }
       
        scoreLabel = new Label("",uiSkin);
        scoreLabel.setPosition(500, 420);
        this.addActor(scoreLabel);
        //this.setDebug(true);
    }
    
    public void update()
    {
        this.life = player.getLife();
        this.score = player.getScore();
        scoreLabel.setText("Score :" + this.score);
        for(int i = 0; i < lifeImages.length;i++)
        {
            if(i < this.life)
            {
                lifeImages[i].setDrawable(lifeDrawable);                
            }
            else
            {
                lifeImages[i].setDrawable(emptyDrawable);
            }
        }   
    }
}
