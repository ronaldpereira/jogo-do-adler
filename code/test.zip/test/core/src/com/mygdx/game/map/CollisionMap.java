/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.map;
import com.mygdx.game.tile.Tile;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.mygdx.game.BoundingBox;
import com.mygdx.game.collidable.CollidableObject;
import com.mygdx.game.CollisionInfo;
import com.mygdx.game.ControllableCharacter;
import com.mygdx.game.collidable.DynamicCollider;
import com.mygdx.game.Quadtree;
import static com.mygdx.game.Axis.*;
import com.mygdx.game.enemy.AbstractEnemy;
import com.mygdx.game.tile.AbstractTile;
import com.mygdx.game.tile.TileFactory;
import static java.lang.Math.abs;
import static java.lang.Math.ceil;
import static java.lang.Math.floor;
import static java.lang.Math.min;
import java.util.ArrayList;
import java.util.Iterator;
/**
 *
 * @author Hiago
 */
public class CollisionMap 
{
    
    protected TileMap map;
    public static final int tileSize = 32;
    
    protected Quadtree movingObjects;
    protected ArrayList<DynamicCollider> localObjs;
    protected ArrayList<DynamicCollider> initialObjs;
    private MapSerializer loadsave;
    private Vector2 spawnPoint = new Vector2(100,100);
    
    public CollisionMap(int width,int height)
    {
        localObjs = new ArrayList<DynamicCollider>();
        //this.loadsave = new MapSerializer(name);
        map = new TileMap(width,height);
        
        //QUADTREE
        movingObjects = new Quadtree(0,new Rectangle(0,0,width * tileSize,height * tileSize)); 
    }
    /*
    public void saveMap()
    {
        loadsave.storeMap(this);
    }
   
    public void loadMap()
    {
        loadsave.loadMap(this);
    }
    */
    
    public void setSpawnPoint(Vector2 point)
    {
        spawnPoint = point;
        
    }
    
    public Vector2 getSpawnPoint()
    {
        return spawnPoint;
    }
    public TileMap getTileMap()
    {
        return map;
    }
    public void addMovingObject(DynamicCollider obj)
    {
        obj.setMap(this);
        movingObjects.insert(obj);
        localObjs.add(obj);
    }
    public void addPlayer(ControllableCharacter player)
    {
        movingObjects.insert(player);
        player.setMap(this);
    }
    //Cria um tile na posição [x][y] usando como guia um certo "gerador"
    //Na prática, o objeto criado será uma copia do gerador mas com posição diferente
    public void createTile(int x,int y,CollidableObject generator)
    {
        if(x < 0 || x > map.getWidth() || y < 0 || y > map.getHeight())
        {
            return;
        }
        clearObjects(x,y); 
        if(generator instanceof AbstractTile)
        {
            map.setTile(x, y, CollidableObjectFactory.createNewTile(x*tileSize,y*tileSize,generator));
        }
        else if(generator instanceof AbstractEnemy)
        {
            addMovingObject(CollidableObjectFactory.createNewEnemy(x*tileSize,y*tileSize,generator));
        }
       
    }
    public void clearTile(int x,int y)
    {
        map.setTile(x, y,TileFactory.createEmpty(x*tileSize,y*tileSize));
    }
    
    public void clearObjects(int x,int y)
    {
        Iterator<DynamicCollider> iter = localObjs.iterator();
        DynamicCollider temp;
        while(iter.hasNext())
        {
            temp = iter.next();
            Vector2 h = map.getHorizontalIntersection(temp.getBoundingBox());
            Vector2 v = map.getVerticalIntersection(temp.getBoundingBox());
            Vector2 origin = map.findTile(temp.getBoundingBox().getX(),temp.getBoundingBox().getY());
            for(int i = (int) h.x;i <= h.y;i++)
            {
                if(new Vector2(i,origin.y).equals(new Vector2(x,y)))
                {
                        movingObjects.remove(temp);
                        iter.remove();
                        return;
                } 
            }
            
            for(int i = (int) v.x;i <= v.y;i++)
            {
                if(new Vector2(origin.x,i).equals(new Vector2(x,y)))
                {
                        movingObjects.remove(temp);
                        iter.remove();
                        return;
                } 
            }
            /*
            if(map.findTile(temp.getBoundingBox().getX(),temp.getBoundingBox().getY()).equals(new Vector2(x,y)))
            {
                movingObjects.remove(temp);
                iter.remove();
            }*/
        }
    }
    
    public void clearPosition(int x,int y)
    {
        if(x < 0 || x >= map.getWidth() || y < 0 || y >= map.getHeight())
        {
            return;
        }
        
        clearTile(x,y);
        clearObjects(x,y);
    }
    
    public void renderMap(SpriteBatch batch)
    {
        map.renderMap(batch);
        
        for(DynamicCollider obj: localObjs)
        {
            obj.drawSelf(batch);
        }
    }
    
    public void removeMovingObject(DynamicCollider obj)
    {
        movingObjects.remove(obj);
    }
    public void update()
    {
        for(DynamicCollider obj : localObjs)
        {
            obj.update();
        }
    }
    
    //DETECÇÃO DE COLISÕES//
    public void closestCollisionX(DynamicCollider entity,int direction,float distance)
    {
        //Se a direção é zero, o objeto não vai se mover nesse eixo
        //logo, não é necessario verificar colisões*
        //*isso só ocorre porque as colisões são sempre bilaterais,
        //Se um outro objeto se move em direção a esse, 
        //a colisão ainda vai ocorrer.
        if(direction == 0)
        {
            return;
        }
        
        //O numero de tiles que o objeto "deseja" andar:
        int tileDistance = (int)ceil(distance/32);
        int xPos;
        BoundingBox box = entity.getBoundingBox();
        int delta = 0;
        Vector2 intersection = map.getVerticalIntersection(box);
       
        ArrayList<DynamicCollider> nearby = movingObjects.getNearby(entity);
        
        float colDistance = -1;
        //-1 aqui sinaliza apenas que o valor ainda não foi inicializado.
        CollidableObject colObj = null;
        
        //A lista de todos os objetos dinamicos próximos a esse 
        //é percorrida, e é encontrado o objeto primeiro objeto com o qual
        //esse colide
        for(DynamicCollider obj : nearby)
        {
            if(map.checkIntersection(intersection,map.getVerticalIntersection(obj.getBoundingBox())))
            {
                if(box.getHorizontalDistance(obj.getBoundingBox()) <= distance)
                {
                    if((obj.getBoundingBox().getX() < entity.getBoundingBox().getX() && direction < 0) ||(obj.getBoundingBox().getX() > entity.getBoundingBox().getX() && direction > 0))
                    {
                        if(obj.getBlocks())
                        {
                            if(colDistance == -1)
                            {
                                colDistance = box.getHorizontalDistance(obj.getBoundingBox());  
                                colObj = obj;
                            }
                            else if(box.getHorizontalDistance(obj.getBoundingBox()) < colDistance)
                            {
                                colDistance = box.getHorizontalDistance(obj.getBoundingBox());  
                                colObj = obj;
                            }
                        }
                    }//colObj = obj;
                }  
            }    
        }
        
        if(colDistance != -1)
        {
            //Se o valor de colDistance não é -1, uma colisão foi encontrada,
            //Então a distancia maxima que o objeto pode andar é então ajustada.
            tileDistance = min((int)ceil(colDistance/32),tileDistance);
        }   
        
        //Depois de verificar as colisões dinamicas, 
        //são verificadas as colisões estaticas, em busca de um tile ainda mais
        //proximo do personagem que o objeto dinamico previamente encontrado.
           
        if(direction > 0)
        {
            xPos = (int)(map.findTile((int)box.getRight(),(int)box.y).x);
        }
        else
        {
            xPos = (int)(map.findTile((int)box.getLeft(),(int)box.y).x);
        }
        
        while(xPos >= 0 && xPos < map.getWidth())
        {

            for(int i = (int)intersection.x; i <= (int)intersection.y; i++)
            {
                if(i < 0 || i > map.getWidth())
                {
                    return;
                }
                if(map.getTile(xPos,i).getCollides())
                {    
                    if(map.getTile(xPos,i).getBlocks())
                    {
                        if(colObj != null)
                        {
                            colObj = map.getTile(xPos,i);
                            break;
                        }
                    }
                }
            }

            delta += 1;  
            xPos += (delta * direction);
            
            if(delta > tileDistance)
            {
                break;
            }
        }
        
        if(colObj == null)
        {
            horizontalCollision(entity,direction,distance);
        }
        else
        {
            horizontalCollision(entity,direction,box.getHorizontalDistance(colObj.getBoundingBox()));
        }
    }
    
    private void horizontalCollision(DynamicCollider entity,int direction,float distance)
    {
        
        //movingObjects.clear();
        int tileDistance = (int)ceil(distance/32);
        int xPos;
        BoundingBox box = entity.getBoundingBox();
        int delta = 0;
        Vector2 intersection = map.getVerticalIntersection(box);
 
        ArrayList<DynamicCollider> nearby = movingObjects.getNearby(entity);
        
        for(DynamicCollider obj : nearby)
        {
            if(map.checkIntersection(intersection,map.getVerticalIntersection(obj.getBoundingBox())))
            {
                if(box.getHorizontalDistance(obj.getBoundingBox()) <= distance)
                {
                    if((obj.getBoundingBox().getX() < entity.getBoundingBox().getX() && direction < 0) ||(obj.getBoundingBox().getX() > entity.getBoundingBox().getX() && direction > 0))
                    {     
                        entity.collide(obj,new CollisionInfo(entity,HORIZONTAL_AXIS));
                        obj.collide(entity,new CollisionInfo(obj,HORIZONTAL_AXIS));
                    }//colObj = obj;
                }
            }    
        }   
        
        if(direction > 0)
        {
            xPos = (int)(map.findTile((int)box.getRight(),(int)box.y).x);
        }
        else
        {
            xPos = (int)(map.findTile((int)box.getLeft(),(int)box.y).x);
        }
        
        while(xPos >= 0 && xPos < map.getWidth())
        {

            for(int i = (int)intersection.x; i <= (int)intersection.y; i++)
            {
                if(map.getTile(xPos,i).getCollides())
                {    
                    entity.collide(map.getTile(xPos,i),new CollisionInfo(entity,HORIZONTAL_AXIS));
                    map.getTile(xPos,i).collide(entity,new CollisionInfo(map.getTile(xPos,i),HORIZONTAL_AXIS));
                }
            }

            delta += 1;  
            xPos += (delta * direction);
            
            if(delta > tileDistance + 1)
            {
                break;
            }
        }
    }
    
    public void closestCollisionY(DynamicCollider entity,int direction,float distance)
    {
        if(abs(direction) == 0)
        {
            return;
        }
        int tileDistance = (int)ceil(distance/32);
        int yPos;
        BoundingBox box = entity.getBoundingBox();
        int delta = 0;
        Vector2 intersection = map.getHorizontalIntersection(box);
        
        ArrayList<DynamicCollider> nearby = movingObjects.getNearby(entity);
        
        float colDistance = -1;
        CollidableObject colObj = null;
        
        for(DynamicCollider obj : nearby)
        {
            //System.out.println(localObjs.size());
            //if(entity.boundingBox.overlaps(obj.boundingBox) && entity != obj)
            //{
            if(map.checkIntersection(intersection,map.getHorizontalIntersection(obj.getBoundingBox())))
            {
                if(box.getVerticalDistance(obj.getBoundingBox()) <= distance)
                {
                    if((obj.getBoundingBox().getY() < entity.getBoundingBox().getY() && direction < 0) ||(obj.getBoundingBox().getY() > entity.getBoundingBox().getY() && direction > 0))
                    {
                        if(obj.getBlocks())
                        {
                            if(colDistance == -1)
                            {
                                colDistance = box.getVerticalDistance(obj.getBoundingBox());  
                                colObj = obj;
                            }
                            else if(box.getVerticalDistance(obj.getBoundingBox()) < colDistance)
                            {
                                colDistance = box.getVerticalDistance(obj.getBoundingBox());  
                                colObj = obj;
                            }
                        }
                    }
                }
            }    
        }
        
        if(colDistance != -1)
        {
            tileDistance = min((int)ceil(colDistance/32),tileDistance);
        }
        if(direction > 0)
        {
            yPos = (int)(map.findTile((int)box.x,(int)box.getUp()).y);
        }
        else
        {
            yPos = (int)(map.findTile((int)box.x,(int)box.getDown()).y);
        }
        
        while(yPos >= 0 && yPos < map.getHeight())
        {

            for(int i = (int)intersection.x; i <= (int)intersection.y; i++)
            {
                if(i < 0 || i > map.getHeight())
                {
                    return;
                }
                
                if(map.getTile(i,yPos).getCollides())
                {    
                    if(map.getTile(i,yPos).getBlocks())
                    {
                        if(colObj != null)
                        {
                            if(box.getVerticalDistance(colObj.getBoundingBox()) < box.getVerticalDistance(map.getTile(i,yPos).getBoundingBox()))
                            {
                                colObj = map.getTile(i,yPos);
                                break;
                            }
                        }
                        else
                        {
                            colObj = map.getTile(i,yPos);
                            break;
                        }
                    }
                }
            }

            delta += 1;  
            yPos += (delta * direction);
            
            if(delta > tileDistance)
            {
                break;
            }
        }
        
        if(colObj == null)
        {
            verticalCollision(entity,direction,distance);
        }
        
        else
        {
            verticalCollision(entity,direction,box.getVerticalDistance(colObj.getBoundingBox()));
        }
    }
    
    private void verticalCollision(DynamicCollider entity,int direction,float distance)
    {
        if(direction == 0)
        {
            return;
        }

        int tileDistance = (int)ceil(distance/32);
        int yPos;
        BoundingBox box = entity.getBoundingBox();
        int delta = 0;
        Vector2 intersection = map.getHorizontalIntersection(box);
        
        ArrayList<DynamicCollider> nearby = movingObjects.getNearby(entity);
        
        for(DynamicCollider obj : nearby)
        {
            if(map.checkIntersection(intersection,map.getHorizontalIntersection(obj.getBoundingBox())))
            {
                if(box.getVerticalDistance(obj.getBoundingBox()) <= distance)
                {
                    if((obj.getBoundingBox().getY() < entity.getBoundingBox().getY() && direction < 0) ||(obj.getBoundingBox().getY() > entity.getBoundingBox().getY() && direction > 0))
                    {     
                        entity.collide(obj,new CollisionInfo(entity,VERTICAL_AXIS));
                        obj.collide(entity,new CollisionInfo(obj,VERTICAL_AXIS));
                    }
                    
                }
            }    
        }   
        
        if(direction > 0)
        {
            yPos = (int)(map.findTile((int)box.x,(int)box.getUp()).y);
        }
        else
        {
            yPos = (int)(map.findTile((int)box.x,(int)box.getDown()).y);
        }
        
        while(yPos >= 0 && yPos < map.getHeight())
        {

            for(int i = (int)intersection.x; i <= (int)intersection.y; i++)
            {
                if(map.getTile(i,yPos).getCollides())
                {    
                    entity.collide(map.getTile(i,yPos),new CollisionInfo(entity,VERTICAL_AXIS));
                    map.getTile(i,yPos).collide(entity,new CollisionInfo(map.getTile(i,yPos),VERTICAL_AXIS));
                }
            }

            delta += 1;  
            yPos += (delta * direction);
            
            if(delta > tileDistance + 1)
            {
                break;
            }
        }
    }
}