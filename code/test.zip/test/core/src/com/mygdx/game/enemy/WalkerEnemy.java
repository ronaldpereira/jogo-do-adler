package com.mygdx.game.enemy;

import com.badlogic.gdx.math.Vector2;
import com.mygdx.game.CollisionInfo;
import com.mygdx.game.collidable.ICollidable;
import com.mygdx.game.TextureSheet;
import static java.lang.Math.signum;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hiago
 */
public class WalkerEnemy extends AbstractEnemy
{
    private WalkerEnemy()
    {
        super(new Vector2(0,0),null,false);
    }
    
    public WalkerEnemy(Vector2 initialPos, TextureSheet sheet, Boolean animates) {
        super(initialPos,sheet,animates);
    }
    
    @Override
    public void updateMovement() 
    {
        setOrigin();
        if(!grounded)
        {
            System.out.println("!grounded");
            return;
        }
        
        Vector2 inter = map.getTileMap().getVerticalIntersection(this.getBoundingBox());
        
        Boolean frontBlocked = false;
        Vector2 tilePosition;
        
        for(int i = (int)inter.x ; i <= inter.y ;i++)
        {
            //Verifica se o(s) tile(s) imediatamente na frente desse personagem esta bloqueado:
            tilePosition = map.getTileMap().findTile(xOrigin,i * map.getTileMap().getTileSize());
            
            //System.out.println(tilePosition);
            if(map.getTileMap().getTile((int)tilePosition.x + direction, (int)tilePosition.y).getBlocks())
            {
                System.out.println(map.getTileMap().getTile((int)tilePosition.x + direction, (int)tilePosition.y).getBoundingBox());
                frontBlocked = true;
            }
            //Verifica se o personagem vai cair se ele andar mais um tile:
        }
        
        Boolean frontEmpty;
        tilePosition = map.getTileMap().findTile(xOrigin, getBoundingBox().getY());
        frontEmpty = !map.getTileMap().getTile((int)tilePosition.x + direction, (int)tilePosition.y - 1).getBlocks();
        
        //Se um dos dois é verdade, o personagem muda de direção.
        if(frontEmpty || frontBlocked)
        {

            direction *= -1;

        }
        currentSpeed.x = 3f * direction;
        flipImageDirection = signum(currentSpeed.x) < 0;  
    }
    
    @Override
    public void collide(ICollidable obj,CollisionInfo info)
    {
        obj.handleCollision(this,info);
    }
    
}
