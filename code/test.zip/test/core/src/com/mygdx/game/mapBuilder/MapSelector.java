/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.mapBuilder;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import java.io.File;

/**
 *
 * @author Hiago
 */
public class MapSelector extends Table 
{   
    //Essa clase representa a UI do seletor de mapas no editor de niveis;
   
    String currentMap;      
    String stageName;
    FileHandle[] maps;
    FileHandle file;
    int selectedStage = 0;
    
    public MapSelector(String stageName, Skin uiSkin)
    {
       
        this.stageName = stageName;
        file = Gdx.files.local(stageName);
        maps = file.list();
        
        //Cada diretorio representa um mapa diferente e tem um botão designado a ele
        Label tmpLabel;
        Button tmpButton;
        int i = 0;
        for(FileHandle map : maps)
        {
            if(map.isDirectory())
            {
                final int index = i;
                tmpLabel = new Label(map.name(),uiSkin);
                tmpButton = new Button(tmpLabel,uiSkin);
                tmpButton.addListener(new ClickListener()
                {
                    @Override
                    public void clicked(InputEvent event,float x,float y)
                    {
                        selectedStage = index;
                        System.out.println(index);
                    }
                }
                );
                this.add(tmpButton).width(100).pad(10);
                this.row();
                i++;
            }
        }
    }
}
