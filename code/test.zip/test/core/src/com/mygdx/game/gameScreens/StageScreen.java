/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.gameScreens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.mygdx.game.map.CollisionMap;
import com.mygdx.game.ControllableCharacter;
import com.mygdx.game.FollowerCamera;
import com.mygdx.game.HUD;
import com.mygdx.game.level.Level;

/**
 *
 * @author Hiago
 */
public class StageScreen extends ScreenAdapter
{
    Game game;
    Skin uiSkin = new Skin(Gdx.files.internal("gameSkin.json"));
    FollowerCamera camera;
    SpriteBatch batch;
    SpriteBatch uiBatch;
    private static ControllableCharacter player;
    private static CollisionMap map;
    private static Level level;
    HUD hud;
    Stage stage;
    BackToMenuDialog back;
    
    public StageScreen(ControllableCharacter p,Level l,Game game)
    {
        this.game = game;
   
        InitialScreen.levelMusic.setLooping(true);
        InitialScreen.levelMusic.play();
        
        player = p;
        level = l;
        player.setLevelNode(level.getCurrentNode());
       
        map = level.getCurrentNode().getMap();
        map.addPlayer(player);
        batch = new SpriteBatch();
        uiBatch = new SpriteBatch();
        
        camera = new FollowerCamera(map,0,0,50,75, player.getBoundingBox());
        camera.setToOrtho(false,640,360);
        
        hud = new HUD(player, new Skin(Gdx.files.internal("gameSkin.json")));
        stage = hud;
        back = new BackToMenuDialog(uiSkin,game);
        back.setVisible(false);
        stage.addActor(back);
        Gdx.input.setInputProcessor(hud);
    }
    
    @Override
    public void render(float delta)
    {
        Gdx.gl.glClearColor(0.2f, 0.2f, 0.5f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        
        if(Gdx.input.isKeyPressed(Input.Keys.ESCAPE))
        {
            back.setVisible(true);
            back.show(hud);         
            //this.dispose();
            //game.setScreen(new InitialScreen(game));
        }
        
        player.update();
        map.update();
        hud.update();
        camera.update();
        
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        
        map.renderMap(batch);
        player.drawSelf(batch);
        batch.end();
        
        hud.act();
        hud.draw();
    }
    public static void nextLevel()
    {
        player.setLevelNode(level.getCurrentNode());
        map = level.getCurrentNode().getMap();
        map.addPlayer(player);
    }
    @Override
    public void dispose()
    {
        batch.dispose();
    }
    @Override
    public void resize(int width, int height)
    {
         System.out.println(stage.getViewport().getScreenWidth() + " " + stage.getViewport().getScreenHeight());
        stage.getViewport().update(width, height, true);
    }
}
