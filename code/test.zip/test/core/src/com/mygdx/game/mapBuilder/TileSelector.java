/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.mapBuilder;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.mygdx.game.collidable.CollidableObject;
import com.mygdx.game.map.CollisionMap;
import java.util.ArrayList;

/**
 *
 * @author Hiago
 */
public class TileSelector extends Table      
{
    ArrayList<ImageButton> tileButtons;
    Image tilePicker;
    int tileIndex = 0;
    
    public TileSelector(ArrayList<CollidableObject> possibleTiles)
    {
        super();
        TextureRegion temp;
        tileButtons = new ArrayList<ImageButton>();
        tilePicker = new Image(new Texture("picker.png"));
        
        for(CollidableObject tile : possibleTiles)
        {
            if(tile.getSheet() != null)
            {
                temp = new TextureRegion(tile.getSheet().getFrame(0));
                temp.setRegionWidth(CollisionMap.tileSize);
                temp.setRegionHeight(CollisionMap.tileSize);
                tileButtons.add(new ImageButton(new TextureRegionDrawable(temp)));
            }
        }
        
        for(int i = 0;i < tileButtons.size();i++)
        {
            final int index = i;
            
            tileButtons.get(i).addListener(new ClickListener()
            {
                @Override
                public void clicked(InputEvent event,float x,float y)
                {
                    tilePicker.setVisible(true);
                    tileIndex = index;
                    System.out.println("Eu funciono!");
                    tilePicker.setPosition(tileButtons.get(index).getX(),tileButtons.get(index).getY());
                }
            }
            );
            
            this.add(tileButtons.get(i)).uniform();
            if((i + 1) % 4 == 0)
            {
                this.row();
            }
        }
        tilePicker.setVisible(false);
        this.add(tilePicker);
        
    }
    
    public int getTileIndex()
    {
        return tileIndex;
    }
}
