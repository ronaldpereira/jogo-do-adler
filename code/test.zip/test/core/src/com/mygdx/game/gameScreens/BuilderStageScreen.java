/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.gameScreens;

import com.badlogic.gdx.Game;
import com.mygdx.game.ControllableCharacter;
import com.mygdx.game.level.Level;

/**
 *
 * @author Hiago
 */
public class BuilderStageScreen extends StageScreen 
{
    public BuilderStageScreen(ControllableCharacter p,Level l,Game game)
    {
        super(p,l,game);
    }
}
