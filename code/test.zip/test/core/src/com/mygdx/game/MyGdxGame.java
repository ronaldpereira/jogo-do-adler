package com.mygdx.game;

import com.mygdx.game.map.CollisionMap;
import com.mygdx.game.mapBuilder.MapBuilder;
import com.mygdx.game.gameScreens.BuilderScreen;
import com.mygdx.game.enemy.AbstractEnemy;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Rectangle;
import com.mygdx.game.gameScreens.InitialScreen;

public class MyGdxGame extends Game 
{    
        FollowerCamera camera;
        OrthographicCamera cameraBuilder;
	SpriteBatch batch;
        CollisionMap mp;
        AbstractEnemy enemy;
        BuilderScreen editorScreen;
        //
        MapBuilder mapB;
        Screen teste;
        
	@Override
	public void create () {
            //camera.setToOrtho(false,800,400);
            //batch = new SpriteBatch();
            mp = new CollisionMap(64,64);
            //mp.loadMap();
            //droplet = new Texture("Purp.png");

            //cameraBuilder = new OrthographicCamera();
            //cameraBuilder.setToOrtho(false,800,400);
            
            this.setScreen(new InitialScreen(this));
	}

	@Override
	public void render () 
        {
            super.render();
	}
	
	@Override
	public void dispose () {

	}
}
