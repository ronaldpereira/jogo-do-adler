/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game.state;

import com.mygdx.game.ControllableCharacter;

/**
 *
 * @author Hiago
 */
public class EmptyPlayerState implements IPlayerState
{
    StateMachine machine;
    protected ControllableCharacter player;
    public EmptyPlayerState(StateMachine machine,ControllableCharacter player)
    {
        this.machine = machine;
        this.player = player;
    }
    public void update()
    {}
    public void handleInput()
    {}
    public void onEnter()
    {}
    public void onExit()
    {}
}
